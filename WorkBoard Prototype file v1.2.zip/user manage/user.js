const filter = document.querySelector('.filter-container');
const filterDropdown = document.querySelector('.filter-dropdown-container');

const filterDept = document.querySelector('.filter-dept');
const filterId = document.querySelector('.filter-id');
const filterCourse = document.querySelector('.filter-course');

const deptSearch = document.querySelector('.dept-search');
const idSearch = document.querySelector('.id-search');
const courseSearch = document.querySelector('.course-search');

filter.onclick = ()=>{
    filterDropdown.classList.toggle('active');
    if(filterDropdown.classList.contains('active')){
        filter.style.background = "GHostWhite";
    }
    else{
        filter.style.background = "white";
    }
}

filterDept.onclick = ()=>{
    deptSearch.classList.add('active');
    idSearch.classList.remove('active');
    courseSearch.classList.remove('active');
}
filterId.onclick = ()=>{
    deptSearch.classList.remove('active');
    idSearch.classList.add('active');
    courseSearch.classList.remove('active');
}
filterCourse.onclick = ()=>{
    deptSearch.classList.remove('active');
    idSearch.classList.remove('active');
    courseSearch.classList.add('active');
}


const accDrop = document.querySelector('.account-dropdown');
const menuDrop = document.querySelector('.dropdown-menu');

accDrop.onclick = ()=>{
    if(accDrop.classList.contains('show') || menuDrop.classList.contains('show')){
        accDrop.classList.remove('show');
        menuDrop.classList.remove('show');
    }
    else{
        accDrop.classList.add('show');
        menuDrop.classList.add('show');
        document.querySelector('.dropdown-toggle').style.background = "#07658dcc";
        document.querySelector('.dropdown-toggle').style.border = "#07658dcc";
    }
}