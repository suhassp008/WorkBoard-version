const login = document.querySelector('.login-inputs');
const forgot = document.querySelector('.forgot-password');

const loginToForgot = document.querySelector('.forgot-pass-click');
const BackToLogin = document.querySelector('.reset-pass');

loginToForgot.onclick = ()=>{
    forgot.style.display = "flex";
    login.style.display = "none";
}
BackToLogin.onclick = ()=>{
    forgot.style.display = "none";
    login.style.display = "flex";
}

