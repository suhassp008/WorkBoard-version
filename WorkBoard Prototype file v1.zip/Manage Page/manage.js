const courseShow = document.querySelector('.course-body');
const manageShow = document.querySelector('.manage-body');


const courseBtn = document.querySelector('.course-btn');
const manageBtn = document.querySelector('.order-btn');

courseBtn.onclick = ()=>{
    courseBtn.classList.add('selected');
    manageBtn.classList.remove('selected');

    courseShow.style.display = "block";
    manageShow.style.display = "none";
}

manageBtn.onclick = ()=>{
    courseBtn.classList.remove('selected');
    manageBtn.classList.add('selected');

    courseShow.style.display = "none";
    manageShow.style.display = "block";
}



const accDrop = document.querySelector('.account-dropdown');
const menuDrop = document.querySelector('.dropdown-menu');

accDrop.onclick = ()=>{
    if(accDrop.classList.contains('show') || menuDrop.classList.contains('show')){
        accDrop.classList.remove('show');
        menuDrop.classList.remove('show');
    }
    else{
        accDrop.classList.add('show');
        menuDrop.classList.add('show');
        document.querySelector('.dropdown-toggle').style.background = "#07658dcc";
        document.querySelector('.dropdown-toggle').style.border = "#07658dcc";
    }
}